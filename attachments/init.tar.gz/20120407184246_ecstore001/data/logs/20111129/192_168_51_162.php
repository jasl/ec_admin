<?php exit()?>
2011-11-29 01:10:44	Resolving api.shopexecp.cn... 
2011-11-29 01:10:44	122.226.100.3
2011-11-29 01:10:44	Connecting to api.shopexecp.cn|122.226.100.3|:80... connected.
2011-11-29 01:10:44	HTTP request sent, awaiting response... 
2011-11-29 01:10:44	200
2011-11-29 01:10:44	 OK
2011-11-29 01:11:04	Resolving service.ecos.shopex.cn... 
2011-11-29 01:11:04	202.91.251.245
2011-11-29 01:11:04	Connecting to service.ecos.shopex.cn|202.91.251.245|:80... connected.
2011-11-29 01:11:04	HTTP request sent, awaiting response... 
2011-11-29 01:11:04	200
2011-11-29 01:11:04	 OK
2011-11-29 01:11:34	recommended_misc_task::minute
2011-11-29 01:11:34	recommended_misc_task::hour
2011-11-29 01:11:34	recommended_misc_task::day
2011-11-29 01:11:34	recommended_misc_task::week
2011-11-29 01:11:34	recommended_misc_task::month
2011-11-29 01:11:34	b2c_misc_task::minute
2011-11-29 01:11:34	b2c_misc_task::hour
2011-11-29 01:11:34	b2c_misc_task::day
2011-11-29 01:11:34	b2c_misc_task::week
2011-11-29 01:11:34	b2c_misc_task::month
2011-11-29 01:11:34	ectools_misc_task::minute
2011-11-29 01:11:34	ectools_misc_task::hour
2011-11-29 01:11:35	ectools_misc_task::day
2011-11-29 01:11:35	ectools_misc_task::week
2011-11-29 01:11:35	ectools_misc_task::month
2011-11-29 01:11:35	site_misc_task::minute
2011-11-29 01:11:35	site_misc_task::hour
2011-11-29 01:11:35	site_misc_task::day
2011-11-29 01:11:35	site_misc_task::week
2011-11-29 01:11:35	site_misc_task::month
2011-11-29 01:11:35	base_misc_task::minute
2011-11-29 01:11:35	base_misc_task::hour
2011-11-29 01:11:35	base_misc_task::day
2011-11-29 01:11:35	base_misc_task::week
2011-11-29 01:11:35	base_misc_task::month
2011-11-29 01:12:36	recommended_misc_task::minute
2011-11-29 01:12:36	b2c_misc_task::minute
2011-11-29 01:12:36	ectools_misc_task::minute
2011-11-29 01:12:36	site_misc_task::minute
2011-11-29 01:12:36	base_misc_task::minute
