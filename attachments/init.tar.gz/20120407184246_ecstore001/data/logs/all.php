<?php exit()?>
2011-11-28 17:09:29	Using sample :/data/httpd/xuexiao1/app/base/examples/config.php
2011-11-28 17:09:29	Writing config file... ok.
2011-11-28 17:09:29	Writing config compat... ok.
2012-04-03 06:58:03	Using sample :/var/www/html/001/app/base/examples/config.php
2012-04-03 06:58:03	Writing config file... ok.
2012-04-03 06:58:03	Writing config compat... ok.
2012-04-03 07:25:56	Using sample :/var/www/html/001/app/base/examples/config.php
2012-04-03 07:25:56	Writing config file... ok.
2012-04-03 07:25:56	Writing config compat... ok.
